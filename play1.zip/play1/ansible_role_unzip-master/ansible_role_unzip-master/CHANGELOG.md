## v1.0.0

- Installs/Unistall Unzip
- CI enabled
